package com.GroupE.crud_api.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudApiDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudApiDemoApplication.class, args);
	}

}
