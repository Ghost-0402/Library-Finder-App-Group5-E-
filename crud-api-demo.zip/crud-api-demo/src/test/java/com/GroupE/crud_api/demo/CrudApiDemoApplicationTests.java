package com.GroupE.crud_api.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudApiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
