package com.example.libraryfinder;

import com.google.gson.annotations.SerializedName;

public class VolumeInfo {
    public String title;
    public String[] authors;  // Array
    public String description;
    public String[] categories;  // Array
}