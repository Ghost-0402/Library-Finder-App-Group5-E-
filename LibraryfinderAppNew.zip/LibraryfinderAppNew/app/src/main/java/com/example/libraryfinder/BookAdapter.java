package com.example.libraryfinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.libraryfinder.data.Book;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;  // For functional interfaces

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {
    private List<Book> books;
    private Consumer<Book> onItemClick;  // For viewing details
    private Consumer<Book> onAddToCatalog;  // For adding to catalog
    private Consumer<Book> onFavoriteToggle;  // For toggling favorite

    // Updated constructor: Now accepts three Consumer<Book> callbacks
    public BookAdapter(Consumer<Book> onItemClick, Consumer<Book> onAddToCatalog, Consumer<Book> onFavoriteToggle) {
        this.onItemClick = onItemClick;
        this.onAddToCatalog = onAddToCatalog;
        this.onFavoriteToggle = onFavoriteToggle;
        this.books = new ArrayList<>();
    }

    public void updateBooks(List<Book> newBooks) {
        this.books = (newBooks != null) ? newBooks : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = books.get(position);
        if (holder.titleText != null) holder.titleText.setText(book.getTitle());
        if (holder.authorText != null) holder.authorText.setText(book.getAuthor() + " (" + book.getCategory() + ")");

        // Item click for details
        holder.itemView.setOnClickListener(v -> {
            if (onItemClick != null) onItemClick.accept(book);
        });

        // Add to catalog button (visible for API books only)
        // Note: android.R.layout.simple_list_item_2 doesn't have buttons, so this is a placeholder.
        // For a real button, create a custom item_book.xml layout with a Button (ID: addToCatalogButton).
        // For now, you can add a button programmatically or use a custom layout.
        if (book.getId() == null || book.getId() == 0) {  // API books
            // Placeholder: Log or show a toast. Replace with actual button logic.
            // Example: holder.addToCatalogButton.setVisibility(View.VISIBLE);
            // holder.addToCatalogButton.setOnClickListener(v -> onAddToCatalog.accept(book));
        }

        // Favorite toggle (placeholder for icon)
        // Note: android.R.layout.simple_list_item_2 doesn't have an ImageView, so this is a placeholder.
        // For a real icon, create a custom item_book.xml layout with an ImageView (ID: favoriteIcon).
        // For now, you can add an ImageView programmatically or use a custom layout.
        // Example: holder.favoriteIcon.setImageResource(book.isFav() ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
        // holder.favoriteIcon.setOnClickListener(v -> onFavoriteToggle.accept(book));
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView titleText, authorText;
        // Add these if using a custom layout:
        // Button addToCatalogButton;
        // ImageView favoriteIcon;

        BookViewHolder(@NonNull View itemView) {
            super(itemView);
            titleText = itemView.findViewById(android.R.id.text1);
            authorText = itemView.findViewById(android.R.id.text2);
            if (titleText != null) {
                titleText.setTextSize(18);
                titleText.setTextColor(itemView.getContext().getResources().getColor(android.R.color.black));
            }
            if (authorText != null) {
                authorText.setTextSize(14);
                authorText.setTextColor(itemView.getContext().getResources().getColor(android.R.color.darker_gray));
            }
            // If using custom layout, initialize here:
            // addToCatalogButton = itemView.findViewById(R.id.addToCatalogButton);
            // favoriteIcon = itemView.findViewById(R.id.favoriteIcon);
        }
    }
}