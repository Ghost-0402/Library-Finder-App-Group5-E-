package com.example.libraryfinder.data;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import java.io.Serializable;

@Entity(tableName = "book", indices = {@Index(value = {"title", "author"}, unique = true)})  // Added unique index on title and author
public class Book implements Serializable {
    @PrimaryKey(autoGenerate = true)
    public Long id = 0L;  // Long for null support

    public String title;
    public String author;
    public String category;
    public String description;
    public boolean isFav = false;

    // No-argument constructor
    public Book() {}

    public Book(Long id, String title, String author, String category, String description, boolean isFav) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.category = category;
        this.description = description;
        this.isFav = isFav;
    }

    // Getters
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getCategory() { return category; }
    public String getDescription() { return description; }
    public boolean isFav() { return isFav; }

    // Setters
    public void setId(Long id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setAuthor(String author) { this.author = author; }
    public void setCategory(String category) { this.category = category; }
    public void setDescription(String description) { this.description = description; }
    public void setFav(boolean isFav) { this.isFav = isFav; }

    public void setFavorite(boolean isFav) { this.isFav = isFav; }
}